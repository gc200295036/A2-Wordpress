<?php 
/*
* Template Name: Custom Post Template
* Template Post Type: post
*/
get_headers();
?>

<?php get_footer();
?>